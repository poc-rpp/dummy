import { services } from './services';

export class providerdetails{
    subscriber_id: string="123456789";
    dob: string="1980-12-25";
    first: string;
    last: string;
    group_num: string="1234";
    tax_id_num: string="112233449";
    service_area_zip: string;
    service_provider_id: string="2382348711";
    session_id: string="asldknascolnas";
    services: services[];
  }