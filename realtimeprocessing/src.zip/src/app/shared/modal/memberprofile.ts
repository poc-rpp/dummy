export class memberprofile{
    dob: string;
    member_firstname: string;
    member_lastname: string;
    address_1: string;
    address_2: string;
    patient_gender: string;
    emp_grp: string;
    emp_id: string;
    phone_number: string;
    email: string;
    username: string;
    city:string;
    county:string;
    zip:string;
    dependent_lastname:string;
    dependent_firstname:string;
    dependent_dob:string;
    dependent_gender:string;
    ssn:string;
    bank_name:string;
    bank_number:number;
    routing_number:number;
}