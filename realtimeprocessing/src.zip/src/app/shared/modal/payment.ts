export class payment{
    username : string;
    unique_id:string;
    payment_status:string;
}