export class login{
   public username: string;
   public password: string;
}