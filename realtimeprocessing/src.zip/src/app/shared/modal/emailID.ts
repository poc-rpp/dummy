export class emailID{
    public username: string;
 }