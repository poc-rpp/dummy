export class signupProvider{
    public company_name: string;
    public tax_id: string;
    public npi: string;
    public state: string;
    public speciality: string;
    public phone_number: string;
    public username: string;
    public password: string;
    public question: string;
    public answer: string;
}