export class services{

      public diagnosis_code_line: string;
      public service_from_date:string;
      public service_through_date:string;
      public place_of_service:string;
      public procedure_code:string;
      public billed_amount:number;
      public number_of_units:number;
}