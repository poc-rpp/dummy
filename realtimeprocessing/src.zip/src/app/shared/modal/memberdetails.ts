export class memberdetails{
    id: string;
    dob: Date= new Date("1980-01-01");
    first: string="Krishna";
    last: string="P";
    address: string;
}