export class claimresults{
    transaction_id: string="1";
    total_charge: number;
    total_discount: number;
    total_allowed: number;
    total_paid: number;
    member_responsibility: number;
    discount_amount: number;
    diagnosis_code: string;
    cpt_hcpcs: string;
    charge: number;
    allowed: number;
    paid: number;
    service_member_responsibility: number;
}