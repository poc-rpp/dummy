export class signupInsurancePayer{
    public company_name: string;
    public tax_id: string;
    public state: string;
    public email: string;
    public username: string;
    public password: string;
    public question: string;
    public answer: string;
}