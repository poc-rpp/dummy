export class signupMember{
    public member_firstname: string;
    public member_lastname: string;
    public emp_grp: string;
    public emp_Id: string;
    public phone_number: string;
    public dob: Date;
    public email: string;
    public username: string;
    public password: string;
    public question: string;
    public answer: string;
  }