export class responseTransaction{ 
        public member_product_code :string;
        public member_product_code_desc:string;
        public max_deductible_par_single:string;
        public max_deductible_par_family:string;
        public max_oop_par_single:string;
        public max_oop_par_family:string;
        public max_deductible_non_par_single:string;
        public max_deductible_non_par_family:string;
        public max_oop_non_par_single:string;
        public max_oop_non_par_family:string;
        public routine_preventative_care:string;
        public office_visit_copay:string;
        public specialist_copay:string;
        public urgent_care_copay:string;
}