/*
 * Public API Surface of zxing-scanner
 */

export * from '../../../node_modules/@zxing/ngx-scanner/public_api';
